# !/usr/bin/env python
# -*- coding: utf-8 -*-
# huobi config
HUOBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
}

CHBTC = {
    "CNY_1":
        {
            "ACCESS_KEY": "c80aa15c-a786-4e74-a38d-821079f02991",  # 途
            "SECRET_KEY": "84237012-6fa0-4817-9036-224d1b9ca412",
            "SERVICE_API": "https://api.chbtc.com/",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
}

JUBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "y9e4m-kqmr8-56326-wqbsr-wj97c-7sdk9-rjh5n",
            "SECRET_KEY": "aWuXC-L%OS(-;JRas-z3{Uh-j{$NE-is3XC-S@f3M",
        }
}

OKCOIN = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITVC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

POLO = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITEX = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OURDAX = {
    "CNY_1":
        {
            "ACCESS_KEY": "",  # depth copy from okcoin
            "SECRET_KEY": "",
        }
}
