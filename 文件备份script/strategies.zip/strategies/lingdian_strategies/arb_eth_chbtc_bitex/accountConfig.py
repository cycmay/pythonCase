# !/usr/bin/env python
# -*- coding: utf-8 -*-
# huobi config
HUOBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
}

CHBTC = {
    "CNY_1":
        {
            "ACCESS_KEY": "fa516b4e-633c-45d4-880f-3799dac8f579",  # 余伟-chbtc2
            "SECRET_KEY": "013e07c1-e439-487d-8c08-5bc916fb2b9c",
            "SERVICE_API": "https://api.chbtc.com/",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
}

JUBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OKCOIN = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITVC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

POLO = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITEX = {
    "CNY_1":
        {
            "ACCESS_KEY": "a3c17d9a-d8117467-68c782f6-07cc9",  # 余伟
            "SECRET_KEY": "dc24edd6-24c3ed6e-479d2fe8-953c6",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OURDAX = {
    "CNY_1":
        {
            "ACCESS_KEY": "",  # depth copy from okcoin
            "SECRET_KEY": "",
        }
}
