# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : huyifeng

import time
import math
from threading import Thread

import logging
import pandas as pd
import numpy
from decimal import Decimal

from signalGenerator.arbitrageStrategy import ArbitrageStrategy
from utils import helper
import stratConfig as cfg
import traceback


class Strat(ArbitrageStrategy):
    def __init__(self, heart_beat_time, coinMarketType, ex_1, ex_2, instance_id=None, startRunningTime=None,
                 name=None, depth_data=None,
                 account_info=None, transaction_info=None):
        """
        搬砖套利策略，在两个交易所之间进行价差套利。在两个交易所都是maker吃单

        :param heart_beat_time:
        :param coinMarketType: 交易对symbol， 如 'eth_cny'
        :param ex_1: 交易所名字，如 'huobi', 'chbtc'
        :param ex_2: 交易所名字，如 'huobi', 'chbtc'
            注意：ex_1与ex_2的顺序，会先在ex_1挂单，成交后，在ex_2对冲
        :param instance_id:
        :param startRunningTime:
        :param name:
        :param depth_data:
        :param account_info:
        :param transaction_info:
        """
        super(Strat, self).__init__(heart_beat_time, coinMarketType, instance_id=instance_id,
                                      startRunningTime=startRunningTime,
                                      name=name, depth_data=depth_data, account_info=account_info,
                                      transaction_info=transaction_info)
        self.ex_1 = ex_1
        self.ex_2 = ex_2
        self.api_1 = None
        self.api_2 = None
        self.init_chbtc_acct_info = None
        self.init_bitex_acct_info = None
        self.bitex_bid_1 = None
        self.bitex_ask_1 = None
        self.chbtc_adj_bid = None
        self.chbtc_adj_ask = None
        self.current_bitex_acct_info = None
        self.current_chbtc_acct_info = None
        self.bitex_cny_reserve = None
        self.bitex_etc_reserve = None
        self.chbtc_cny_reserve = None
        self.chbtc_etc_reserve = None
        self.is_hedge = False
        self.is_square = False
        self.coin_str = coinMarketType.split('_')[0]
        self.init_coin_total = None
        self.init_cash_total = None

    def init_acct_info(self, ex_1_acct_info=None, ex_2_acct_info=None):
        if self.init_cash_total is None or self.init_coin_total is None:
            if not ex_1_acct_info:
                ex_1_acct_info = self.get_account_info(exchange=self.ex_1)
            if not ex_2_acct_info:
                ex_2_acct_info = self.get_account_info(exchange=self.ex_2)
            self.init_cash_total = self.ex_cash_total(self.ex_1, acct_info=ex_1_acct_info) + self.ex_cash_total(
                self.ex_2, acct_info=ex_2_acct_info)
            self.init_coin_total = self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info) + self.ex_coin_total(
                self.ex_2, acct_info=ex_2_acct_info)
            return False
        else:
            return True

    def bid_1_ask_1_info(self, ex):
        info = self.get_depth(ex)
        try:
            bid_1_price, bid_1_vol = info[0][0]
            ask_1_price, ask_1_vol = info[1][0]
            return [bid_1_price, bid_1_vol], [ask_1_price, ask_1_vol]
        except Exception:
            self.timeLog('Error when get bid_1_ask_1_info')

    def current_avg_price(self, ex=None, bid_ask_info=None):
        if bid_ask_info:
            [bid_1_price, bid_1_vol], [ask_1_price, ask_1_vol] = bid_ask_info
        elif ex:
            [bid_1_price, bid_1_vol], [ask_1_price, ask_1_vol] = self.bid_1_ask_1_info(ex)
        else:
            raise Exception('参数至少填写1个')
        return (bid_1_price+ask_1_price)/2

    def ex_max_buy(self, ex, buy_price=None, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        if not buy_price:
            buy_price = self.get_buy_or_sell_n_price_or_vol(self.exchange, buy_or_sell=1, price_or_vol=0) * (1+cfg.SLIPPAGE)
        cash_available = acct_info.cash
        qty = cash_available / buy_price
        return qty

    def ex_coin_total(self, ex, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        coin_total = acct_info.__getattribute__(self.coin_str+'_total')
        return coin_total

    def ex_cash_total(self, ex, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        cash_total = acct_info.__getattribute__('cash_total')
        return cash_total

    def ex_max_sell(self, ex, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        coin_available = acct_info.__getattribute__(self.coin_str)
        return coin_available

    def max_arb_available_qty(self, ex_buy, ex_sell, buy_price=None, ex_buy_acct_info=None, ex_sell_acct_info=None):
        max_buy = self.ex_max_buy(ex=ex_buy, buy_price=buy_price, acct_info=ex_buy_acct_info)
        max_sell = self.ex_max_sell(ex=ex_sell, acct_info=ex_sell_acct_info)
        qty = min(max_buy, max_sell)
        return qty

    def bid1_and_ask1_max_qty(self, ex_buy, ex_sell, ex_buy_ask1_qty=None, ex_sell_bid1_qty=None):
        if not ex_buy_ask1_qty:
            ex_buy_ask1_qty = self.get_buy_or_sell_n_price_or_vol(ex_buy, 1, 1)
        if not ex_sell_bid1_qty:
            ex_sell_bid1_qty = self.get_buy_or_sell_n_price_or_vol(ex_sell, 0, 1)
        qty = min(ex_buy_ask1_qty, ex_sell_bid1_qty)*cfg.DEPTH_RATIO
        return qty

    def arb_qty(self, ex_buy, ex_sell, buy_price=None, ex_buy_acct_info=None, ex_sell_acct_info=None,
                ex_buy_ask1_qty=None, ex_sell_bid1_qty=None):
        acct_max_qty = self.max_arb_available_qty(ex_buy, ex_sell, buy_price=buy_price,
                                                  ex_buy_acct_info=ex_buy_acct_info,
                                                  ex_sell_acct_info=ex_sell_acct_info)
        bid_ask_max_qty = self.bid1_and_ask1_max_qty(ex_buy, ex_sell, ex_buy_ask1_qty=ex_buy_ask1_qty,
                                                     ex_sell_bid1_qty=ex_sell_bid1_qty)
        qty = min(acct_max_qty, bid_ask_max_qty)
        return qty

    def price_spread(self, ex_buy, ex_sell, ex_buy_ask1_price=None, ex_sell_bid1_price=None):
        if not ex_buy_ask1_price:
            ex_buy_ask1_price = self.get_buy_or_sell_n_price_or_vol(ex_buy, 1, 0)
        if not ex_sell_bid1_price:
            ex_sell_bid1_price = self.get_buy_or_sell_n_price_or_vol(ex_sell, 0, 0)
        spread = ex_sell_bid1_price - ex_buy_ask1_price
        return spread

    def get_fee_rate(self, ex):
        if ex == self.ex_1:
            return cfg.EX_1_FEE
        elif ex == self.ex_2:
            return cfg.EX_2_FEE
        else:
            raise Exception('Wrong ex: %s' % ex)

    def trade_return_ratio(self, ex_buy, ex_sell, ex_buy_ask1_price=None, ex_sell_bid1_price=None):
        if not ex_buy_ask1_price:
            ex_buy_ask1_price = self.get_buy_or_sell_n_price_or_vol(ex_buy, 1, 0)
        if not ex_sell_bid1_price:
            ex_sell_bid1_price = self.get_buy_or_sell_n_price_or_vol(ex_sell, 0, 0)
        spread = self.price_spread(ex_buy, ex_sell, ex_buy_ask1_price=ex_buy_ask1_price, ex_sell_bid1_price=ex_sell_bid1_price)
        total_fee = ex_buy_ask1_price * self.get_fee_rate(ex_buy) + ex_sell_bid1_price * self.get_fee_rate(ex_sell)
        profit = spread - total_fee - 2 * cfg.SLIPPAGE
        profit_ratio = profit / ((ex_buy_ask1_price+ex_sell_bid1_price)/2)
        return profit_ratio

    def satisfy_trade(self, ex_buy, ex_sell, target_ratio, min_qty, profit_ratio=None, ex_buy_ask1_price=None,
                      ex_sell_bid1_price=None, ex_buy_acct_info=None, ex_sell_acct_info=None, ex_buy_ask1_qty=None,
                      ex_sell_bid1_qty=None):
        if not profit_ratio:
            profit_ratio = self.trade_return_ratio(ex_buy, ex_sell, ex_buy_ask1_price=ex_buy_ask1_price,
                                                   ex_sell_bid1_price=ex_sell_bid1_price)
        self.timeLog("买入交易所: %s, 卖出交易所: %s" % (ex_buy, ex_sell))
        if profit_ratio < target_ratio:
            self.timeLog("<无信号>Current ret: %.4f, target: %.4f" % (profit_ratio, target_ratio))
            return False
        qty = self.arb_qty(ex_buy, ex_sell, buy_price=ex_buy_ask1_price, ex_buy_acct_info=ex_buy_acct_info,
                           ex_sell_acct_info=ex_sell_acct_info, ex_buy_ask1_qty=ex_buy_ask1_qty,
                           ex_sell_bid1_qty=ex_sell_bid1_qty)
        if qty < min_qty:
            self.timeLog("<交易信号>交易数量: %.4f, 小于最小下单数量: %.4f" % (qty, min_qty))
            return False
        qty = min(qty, cfg.MAX_ORDER_QTY)
        return qty

    def arb_signal(self, ex_buy, ex_sell, profit_ratio=None, ex_buy_ask1_price=None, ex_sell_bid1_price=None,
                         ex_buy_acct_info=None, ex_sell_acct_info=None, ex_buy_ask1_qty=None, ex_sell_bid1_qty=None):
        return self.satisfy_trade(ex_buy, ex_sell, cfg.TARGET_RETURN, cfg.MIN_ORDER_QTY, profit_ratio=profit_ratio,
                                  ex_buy_ask1_price=ex_buy_ask1_price, ex_sell_bid1_price=ex_sell_bid1_price,
                                  ex_buy_acct_info=ex_buy_acct_info, ex_sell_acct_info=ex_sell_acct_info,
                                  ex_buy_ask1_qty=ex_buy_ask1_qty, ex_sell_bid1_qty=ex_sell_bid1_qty)

    def rebalance_signal(self, ex_buy, ex_sell, profit_ratio=None, ex_buy_ask1_price=None, ex_sell_bid1_price=None,
                         ex_buy_acct_info=None, ex_sell_acct_info=None, ex_buy_ask1_qty=None, ex_sell_bid1_qty=None):
        qty = self.satisfy_trade(ex_buy, ex_sell, cfg.REBALANCE_RETURN, cfg.MIN_ORDER_QTY,
                                 profit_ratio=profit_ratio, ex_buy_ask1_price=ex_buy_ask1_price,
                                 ex_sell_bid1_price=ex_sell_bid1_price, ex_buy_acct_info=ex_buy_acct_info,
                                 ex_sell_acct_info=ex_sell_acct_info, ex_buy_ask1_qty=ex_buy_ask1_qty,
                                 ex_sell_bid1_qty=ex_sell_bid1_qty)
        if qty is not False:
            coin_diff = self.ex_coin_diff(ex_buy, ex_sell, ex_1_acct_info=ex_buy_acct_info, ex_2_acct_info=ex_sell_acct_info)
            coin_need_buy = coin_diff / 2
            if coin_need_buy >= cfg.REBALANCE_MIN_DIFF:
                order_qty = min(coin_need_buy, qty)
                return order_qty
        return False

    def ex_coin_diff(self, ex_1, ex_2, ex_1_acct_info=None, ex_2_acct_info=None):
        ex_1_total = self.ex_coin_total(ex_1, acct_info=ex_1_acct_info)
        ex_2_total = self.ex_coin_total(ex_2, acct_info=ex_2_acct_info)
        coin_diff = ex_2_total - ex_1_total
        return coin_diff

    def cancel_ex_pending_orders(self, ex):
        self.timeLog('开始撤销[%s]的所有订单' % ex)
        self.cancel_pending_orders(ex)
        self.timeLog('完成撤销[%s]订单' % ex)

    def cancel_all_ex_pending_orders(self, ex_list):
        for ex in ex_list:
            self.cancel_ex_pending_orders(ex)

    # 相对于账户最开始的delta
    def total_coin_delta(self, ex_1_acct_info=None, ex_2_acct_info=None):
        init_qty = cfg.INIT_COIN
        current_qty = self.ex_coin_total(self.ex_1, ex_1_acct_info) + self.ex_coin_total(self.ex_2, ex_2_acct_info)
        return current_qty - init_qty

    # 相对于本次策略启动的delta
    def current_coin_delta(self, ex_1_acct_info=None, ex_2_acct_info=None):
        init_qty = self.init_coin_total
        current_qty = self.ex_coin_total(self.ex_1, ex_1_acct_info) + self.ex_coin_total(self.ex_2, ex_2_acct_info)
        return current_qty - init_qty

    def total_cash_delta(self, ex_1_acct_info=None, ex_2_acct_info=None):
        init_cash = cfg.INIT_CASH
        current_cash = self.ex_cash_total(self.ex_1, ex_1_acct_info) + self.ex_cash_total(self.ex_2, ex_2_acct_info)
        return current_cash - init_cash

    def current_cash_delta(self, ex_1_acct_info=None, ex_2_acct_info=None):
        init_cash = self.init_cash_total
        current_cash = self.ex_cash_total(self.ex_1, ex_1_acct_info) + self.ex_cash_total(self.ex_2, ex_2_acct_info)
        return current_cash - init_cash

    def cal_pnl(self, coin_delta, cash_delta, price):
        return cash_delta + coin_delta * price

    def total_pnl(self, ex_1_acct_info=None, ex_2_acct_info=None, price=None):
        if not price:
            price = self.current_avg_price(self.ex_1)
        coin_delta = self.total_coin_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info)
        cash_delta = self.total_cash_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info)
        pnl = self.cal_pnl(coin_delta, cash_delta, price)
        self.timeLog("-----------历史收益统计-----------")
        self.timeLog("现金变化：<%.2f>元" % cash_delta)
        self.timeLog("币数变化：<%.4f>个" % coin_delta)
        self.timeLog("总体收益：<%.2f>元" % pnl)

    def current_pnl(self, ex_1_acct_info=None, ex_2_acct_info=None, price=None):
        if not price:
            price = self.current_avg_price(self.ex_1)
        coin_delta = self.current_coin_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info)
        cash_delta = self.current_cash_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info)
        pnl = self.cal_pnl(coin_delta, cash_delta, price)
        self.timeLog("-----------本次收益统计-----------")
        self.timeLog("现金变化：<%.2f>元" % cash_delta)
        self.timeLog("币数变化：<%.4f>个" % coin_delta)
        self.timeLog("本次收益：<%.2f>元" % pnl)
        self.timeLog("-----------当前持仓情况-----------")
        self.timeLog("[%s] 现金: %.2f, 币数: %.2f" % (self.ex_1, ex_1_acct_info.cash_total,
                                                  self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info)))
        self.timeLog("[%s] 现金: %.2f, 币数: %.2f" % (self.ex_2, ex_2_acct_info.cash_total,
                                                  self.ex_coin_total(self.ex_2, acct_info=ex_2_acct_info)))
        self.timeLog("--------------------------------")
        return pnl

    def pnl_monitor(self, ex_1_acct_info=None, ex_2_acct_info=None, bid_ask_info=None, price=None):
        if not price:
            price = self.current_avg_price(ex=self.ex_1, bid_ask_info=bid_ask_info)
        self.total_pnl(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info, price=price)
        current_pnl = self.current_pnl(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info, price=price)
        if -current_pnl > cfg.MAX_LOSS:
            self.timeLog('当前策略亏损: <%.2f>元, 超过预设最大亏损值：<%.2f>元，停止策略' % (-current_pnl, cfg.MAX_LOSS))
            return False
        else:
            return True
    
    def ex_name_to_code(self, ex_name):
        if ex_name == helper.CHBTC:
            return helper.CHBTC_MARKET_TYPE
        elif ex_name == helper.OKCOIN:
            return helper.OKCOIN_MARKET_TYPE
        elif ex_name == helper.BITEX:
            return helper.BITEX_MARKET_TYPE
        elif ex_name == helper.JUBI:
            return helper.JUBI_MARKET_TYPE
    
    def get_coin_type(self, ex):
        if ex == helper.BITEX:
            ex_coin_type = self.coin_type
        else:
            ex_coin_type = self.coinMarketType
        return ex_coin_type

    def arb_trade_buy_first(self, ex_buy, ex_sell, target_qty, buy_price, sell_price):
        buy_price *= (1+cfg.SLIPPAGE)
        sell_price *= (1-3*cfg.SLIPPAGE)
        ex_buy_code = self.ex_name_to_code(ex_buy)
        ex_sell_code = self.ex_name_to_code(ex_sell)
        ex_buy_coin_type = self.get_coin_type(ex_buy)
        ex_sell_coin_type = self.get_coin_type(ex_sell)
        buy_order_id = self.spot_order(ex_buy_code, ex_buy_coin_type, helper.SPOT_TRADE_TYPE_BUY,
                                       helper.ORDER_TYPE_LIMIT_ORDER, price=buy_price, quantity=target_qty)
        time.sleep(2)
        self.cancel_ex_pending_orders(ex_buy)
        deal_qty = self.spot_order_info(ex_buy_code, ex_buy_coin_type, buy_order_id)[1]
        if deal_qty < cfg.MIN_ORDER_QTY:
            return
        self.spot_order(ex_sell_code, ex_sell_coin_type, helper.SPOT_TRADE_TYPE_SELL, helper.ORDER_TYPE_LIMIT_ORDER,
                        price=sell_price, quantity=deal_qty)

    def arb_trade_sell_first(self, ex_buy, ex_sell, target_qty, buy_price, sell_price):
        buy_price *= (1+3*cfg.SLIPPAGE)
        sell_price *= (1-cfg.SLIPPAGE)
        ex_buy_code = self.ex_name_to_code(ex_buy)
        ex_sell_code = self.ex_name_to_code(ex_sell)
        ex_buy_coin_type = self.get_coin_type(ex_buy)
        ex_sell_coin_type = self.get_coin_type(ex_sell)
        sell_order_id = self.spot_order(ex_sell_code, ex_sell_coin_type, helper.SPOT_TRADE_TYPE_SELL, helper.ORDER_TYPE_LIMIT_ORDER,
                        price=sell_price, quantity=target_qty)
        time.sleep(2)
        self.cancel_ex_pending_orders(ex_sell)
        deal_qty = self.spot_order_info(ex_sell_code, ex_sell_coin_type, sell_order_id)[1]
        if deal_qty < cfg.MIN_ORDER_QTY:
            return
        self.spot_order(ex_buy_code, ex_buy_coin_type, helper.SPOT_TRADE_TYPE_BUY, helper.ORDER_TYPE_LIMIT_ORDER,
                        price=buy_price, quantity=deal_qty)

    def arb_trade(self, ex_buy, ex_sell, target_qty, buy_price, sell_price):
        if ex_buy == self.ex_1:
            self.arb_trade_buy_first(ex_buy, ex_sell, target_qty, buy_price, sell_price)
        else:
            self.arb_trade_sell_first(ex_buy, ex_sell, target_qty, buy_price, sell_price)
    
    def strat(self, ex_1_acct_info, ex_2_acct_info, ex_1_depth_info, ex_2_depth_info):
        [ex_1_bid_1_price, ex_1_bid_1_vol], [ex_1_ask_1_price, ex_1_ask_1_vol] = ex_1_depth_info
        [ex_2_bid_1_price, ex_2_bid_1_vol], [ex_2_ask_1_price, ex_2_ask_1_vol] = ex_2_depth_info
        buy_in_ex_1_profit = self.trade_return_ratio(self.ex_1, self.ex_2, ex_1_ask_1_price, ex_2_bid_1_price)
        buy_in_ex_2_profit = self.trade_return_ratio(self.ex_2, self.ex_1, ex_2_ask_1_price, ex_1_bid_1_price)
        ex_1_buy_arb_qty = self.arb_signal(self.ex_1, self.ex_2, profit_ratio=buy_in_ex_1_profit,
                                           ex_buy_ask1_price=ex_1_ask_1_price, ex_sell_bid1_price=ex_2_bid_1_price,
                                           ex_buy_acct_info=ex_1_acct_info, ex_sell_acct_info=ex_2_acct_info,
                                           ex_buy_ask1_qty=ex_1_ask_1_vol, ex_sell_bid1_qty=ex_2_bid_1_vol)
        if ex_1_buy_arb_qty:
            self.timeLog("执行套利，交易数量：<%.4f>" % ex_1_buy_arb_qty)
            self.arb_trade(self.ex_1, self.ex_2, ex_1_buy_arb_qty, ex_1_ask_1_price, ex_2_bid_1_price)
            return
        ex_1_sell_arb_qty = self.arb_signal(self.ex_2, self.ex_1, profit_ratio=buy_in_ex_2_profit,
                                            ex_buy_ask1_price=ex_2_ask_1_price, ex_sell_bid1_price=ex_1_bid_1_price,
                                            ex_buy_acct_info=ex_2_acct_info, ex_sell_acct_info=ex_1_acct_info,
                                            ex_buy_ask1_qty=ex_2_ask_1_vol, ex_sell_bid1_qty=ex_1_bid_1_vol)
        if ex_1_sell_arb_qty:
            self.timeLog("执行套利，交易数量：<%.4f>" % ex_1_sell_arb_qty)
            self.arb_trade(self.ex_2, self.ex_1, ex_1_sell_arb_qty, ex_2_ask_1_price, ex_1_bid_1_price)
            return
        ex_1_buy_reb_qty = self.rebalance_signal(self.ex_1, self.ex_2, profit_ratio=buy_in_ex_1_profit,
                                                 ex_buy_ask1_price=ex_1_ask_1_price,
                                                 ex_sell_bid1_price=ex_2_bid_1_price, ex_buy_acct_info=ex_1_acct_info,
                                                 ex_sell_acct_info=ex_2_acct_info, ex_buy_ask1_qty=ex_1_ask_1_vol,
                                                 ex_sell_bid1_qty=ex_2_bid_1_vol)
        if ex_1_buy_reb_qty:
            self.timeLog("执行再平衡，交易数量：<%.4f>" % ex_1_buy_reb_qty)
            self.arb_trade(self.ex_1, self.ex_2, ex_1_buy_reb_qty, ex_1_ask_1_price, ex_2_bid_1_price)
            return
        ex_1_sell_reb_qty = self.rebalance_signal(self.ex_2, self.ex_1, profit_ratio=buy_in_ex_2_profit,
                                                  ex_buy_ask1_price=ex_2_ask_1_price,
                                                  ex_sell_bid1_price=ex_1_bid_1_price, ex_buy_acct_info=ex_2_acct_info,
                                                  ex_sell_acct_info=ex_1_acct_info, ex_buy_ask1_qty=ex_2_ask_1_vol,
                                                  ex_sell_bid1_qty=ex_1_bid_1_vol)
        if ex_1_sell_reb_qty:
            self.timeLog("执行再平衡，交易数量：<%.4f>" % ex_1_sell_reb_qty)
            self.arb_trade(self.ex_2, self.ex_1, ex_1_sell_reb_qty, ex_2_ask_1_price, ex_1_bid_1_price)
            return
    
    def hedge_delta(self, ex_1_acct_info, ex_2_acct_info, ex_1_depth_info, ex_2_depth_info):
        [ex_1_bid_1_price, ex_1_bid_1_vol], [ex_1_ask_1_price, ex_1_ask_1_vol] = ex_1_depth_info
        [ex_2_bid_1_price, ex_2_bid_1_vol], [ex_2_ask_1_price, ex_2_ask_1_vol] = ex_2_depth_info
        coin_delta = self.current_coin_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info)
        if coin_delta > cfg.MAX_COIN_DELTA:
            self.timeLog('<Signal> Hedge delta. qty = %.4f' % coin_delta)
            self.sell_delta(ex_1_acct_info, ex_2_acct_info, ex_1_bid_1_price, ex_2_bid_1_price, coin_delta)
            return True
        elif -coin_delta > cfg.MAX_COIN_DELTA:
            self.timeLog('<Signal> Hedge delta. qty = %.4f' % coin_delta)
            self.buy_delta(ex_1_acct_info, ex_2_acct_info, ex_1_ask_1_price, ex_2_ask_1_price, -coin_delta)
            return True
        else:
            return False
        
    def buy_delta(self, ex_1_acct_info, ex_2_acct_info, ex_1_ask_1_price, ex_2_ask_1_price, coin_delta):
        ex = None
        ex_1_coin = self.ex_max_buy(self.ex_1, buy_price=ex_1_ask_1_price, acct_info=ex_1_acct_info)
        ex_2_coin = self.ex_max_buy(self.ex_2, buy_price=ex_2_ask_1_price, acct_info=ex_2_acct_info)
        if ex_1_coin >= coin_delta and ex_2_coin >= coin_delta:
            if ex_1_ask_1_price <= ex_2_ask_1_price:
                ex = self.ex_1
            else:
                ex = self.ex_2
        elif ex_1_coin >= coin_delta:
            ex = self.ex_1
        elif ex_2_coin >= coin_delta:
            ex = self.ex_2
        ex_buy_code = self.ex_name_to_code(ex)
        ex_buy_coin_type = self.get_coin_type(ex)
        if ex == self.ex_1:
            buy_price = ex_1_ask_1_price * (1 + cfg.SLIPPAGE)
        else:
            buy_price = ex_2_ask_1_price * (1 + cfg.SLIPPAGE)
        self.spot_order(ex_buy_code, ex_buy_coin_type, helper.SPOT_TRADE_TYPE_BUY,
                        helper.ORDER_TYPE_LIMIT_ORDER, price=buy_price, quantity=coin_delta)
        
    def sell_delta(self, ex_1_acct_info, ex_2_acct_info, ex_1_bid_1_price, ex_2_bid_1_price, coin_delta):
        ex = None
        ex_1_coin = self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info)
        ex_2_coin = self.ex_coin_total(self.ex_2, acct_info=ex_2_acct_info)
        if ex_1_coin >= coin_delta and ex_2_coin >= coin_delta:
            if ex_1_bid_1_price >= ex_2_bid_1_price:
                ex = self.ex_1
            else:
                ex = self.ex_2
        elif ex_1_coin >= coin_delta:
            ex = self.ex_1
        elif ex_2_coin >= coin_delta:
            ex = self.ex_2
        ex_sell_code = self.ex_name_to_code(ex)
        ex_sell_coin_type = self.get_coin_type(ex)
        if ex == self.ex_1:
            sell_price = ex_1_bid_1_price * (1 - cfg.SLIPPAGE)
        else:
            sell_price = ex_2_bid_1_price * (1 - cfg.SLIPPAGE)
        self.spot_order(ex_sell_code, ex_sell_coin_type, helper.SPOT_TRADE_TYPE_SELL,
                        helper.ORDER_TYPE_LIMIT_ORDER, price=sell_price, quantity=coin_delta)
    
    def go(self):
        while True:
            self.cancel_all_ex_pending_orders([self.ex_1, self.ex_2])
            time.sleep(1)
            ex_1_acct_info = self.get_account_info(self.ex_1)
            ex_2_acct_info = self.get_account_info(self.ex_2)
            ex_1_depth_info = self.bid_1_ask_1_info(self.ex_1)
            ex_2_depth_info = self.bid_1_ask_1_info(self.ex_2)
            if not all([ex_1_acct_info, ex_2_acct_info, ex_1_depth_info, ex_2_depth_info]):
                continue
            if not self.init_acct_info(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info):
                continue
            if not self.pnl_monitor(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info, bid_ask_info=ex_1_depth_info):
                continue
            if self.hedge_delta(ex_1_acct_info, ex_2_acct_info, ex_1_depth_info, ex_2_depth_info):
                continue
            self.strat(ex_1_acct_info, ex_2_acct_info, ex_1_depth_info, ex_2_depth_info)
