#!/bin/bash

# for path resolution
# SCRIPT=`readlink -f ${0}`
# SCRIPT_PATH=$(dirname "${SCRIPT}")

help() {
    echo $0 'strategy_name|all command(start|stop|monitor)';
    echo $0 'list';
}

if [ $# -lt 1 ]; then
    echo 'Insufficient arguments';
    help;
    exit;
fi

_STRATEGY=$1

if [ $1 = 'all' ] ; then
    echo 'all parameter is not implemented!';
    exit;
fi

if [ $1 = 'list' ] ; then
	echo '------- listing current running strategys --------';
	ps -U $USER -ux | grep main.py | grep -v grep | awk '{print $13}'| sort | uniq | cut -d '/' -f 1;
	echo '------- ending  current running strategys --------';	
	exit;
fi

case $2 in
    start)
	# check if process exists before starting
	reg='^${_STRATEGY}$'
	#processes=`ps -ef | grep python | grep -v grep | awk '{print $10}' | uniq |cut -d '/' -f 1 | grep '${reg}' | wc -l`
	processes=`ps -ef | grep ${_STRATEGY} | grep python |grep -v grep | wc -l`
	if [ $processes -gt 0 ]; then
	    echo 'Strategy alreader running, please stop it first'
	    exit;
	else
	    echo 'starting '${_STRATEGY};	    
	fi
	
	if [ -f log/${_STRATEGY}.log ]; then
	    echo 'moving logs ...'
	    mv log/${_STRATEGY}.log log/${_STRATEGY}_`date "+%Y-%m-%d_%H_%M_%S"`.log.bak
	    echo 'moving logs complete'
	fi
	
	PYTHONPATH=/home/strategy/strategies/lingdian_strategies/projectX nohup python -u ${_STRATEGY}/main.py > log/${_STRATEGY}.log &
	# check if script running
	processes=`ps -ef | grep ${_STRATEGY} | grep python |grep -v grep | wc -l`
	#processes=`ps -ef | grep python | grep -v grep | awk '{print $10}' | uniq |cut -d '/' -f 1 | grep '^${_STRATEGY}$' | wc -l`	
	if [ $processes -gt 0 ]; then
	    sleep 1;
	    echo 'ok'
	else
	    echo 'starting failed'
	fi
	;;
    
    stop)
	echo 'stoping '${_STRATEGY};
	kill `ps -ef | grep ${_STRATEGY} | grep python | awk '{print $2}'`
	#processes=`ps -ef | grep python | grep -v grep | awk '{print $10}' | uniq |cut -d '/' -f 1 | grep '^${_STRATEGY}$' | wc -l`	
	processes=`ps -ef | grep ${_STRATEGY} | grep python |grep -v grep | wc -l`
	if [ $processes = 0 ]; then
	    echo 'ok'
	else
	    echo 'stoping failed'
	fi
	;;
    
    monitor)
	tail -15f log/${_STRATEGY}.log
	
	;;
    debug)
        less log/${_STRATEGY}.log

        ;;
    accreset)
        PYTHONPATH=/home/strategy/strategies/lingdian_strategies/${_STRATEGY} python3 projectX/cancelAllPendingOrders.py
        echo "Account reset"
        
        ;;
    *)
	echo 'unknown operation '$2;
	exit
	;;
esac
