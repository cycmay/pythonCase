# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee


INIT_COIN = 7.8148
INIT_CASH = 10000

EX_1_FEE = 0.002
EX_2_FEE = 0.002

SLIPPAGE = 0.0005

DEPTH_RATIO = 0.5  # 下单数量占买一/卖一数量的比例

REBALANCE_MIN_DIFF = 5  # 两个交易所执行rebalance的最小个数差值

TARGET_RETURN = 0.003
REBALANCE_RETURN = -0.0018

MIN_ORDER_QTY = 0.01
MAX_ORDER_QTY = 1

MAX_LOSS = 100  # RMB亏损超过此数值时，停止策略
MAX_COIN_DELTA = 0.01  # 当coin delta大于此值时，套利会暂停，执行对冲，直至小于此值