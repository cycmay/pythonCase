# !/usr/bin/env python
# -*- coding: utf-8 -*-
# huobi config
HUOBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
}

CHBTC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
}

JUBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OKCOIN = {
    "CNY_1":
        {
            "ACCESS_KEY": "ae0023bc-65c8-4153-9dbf-cdeac2b67378",  # 牟光遥
            "SECRET_KEY": "1F89855E13D402E23E15A5847F5029F4",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITVC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

POLO = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITEX = {
    "CNY_1":
        {
            "ACCESS_KEY": "7e0206ea-2886d9c0-35c6fd01-cc974",#牟光遥
            "SECRET_KEY": "4683db75-1f60f89a-46f14929-96d72",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OURDAX = {
    "CNY_1":
        {
            "ACCESS_KEY": "",  # depth copy from okcoin
            "SECRET_KEY": "",
        }
}
