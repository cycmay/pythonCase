# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee

import time
import math
from threading import Thread

import logging
import pandas as pd
import numpy
from decimal import Decimal

from signalGenerator.arbitrageStrategy import ArbitrageStrategy
from utils import helper
import stratConfig as cfg


class Strat(ArbitrageStrategy):
    def __init__(self, heart_beat_time, coinMarketType, ex_1, ex_2, instance_id=None, startRunningTime=None,
                 name=None, depth_data=None,
                 account_info=None, transaction_info=None):
        """
        搬砖套利策略，在两个交易所之间进行价差套利。在两个交易所都是maker吃单

        :param heart_beat_time:
        :param coinMarketType: 交易对symbol， 如 'eth_cny'
        :param ex_1: 交易所名字，如 'huobi', 'chbtc'
        :param ex_2: 交易所名字，如 'huobi', 'chbtc'
            注意：ex_1与ex_2的顺序，在ex1向ex2借深度挂单，成交后，在ex2进行对冲
        :param instance_id:
        :param startRunningTime:
        :param name:
        :param depth_data:
        :param account_info:
        :param transaction_info:
        """
        super(Strat, self).__init__(heart_beat_time, coinMarketType, instance_id=instance_id,
                                        startRunningTime=startRunningTime,
                                        name=name, depth_data=depth_data, account_info=account_info,
                                        transaction_info=transaction_info)
        self.ex_1 = ex_1
        self.ex_2 = ex_2
        self.init_coin_total = None
        self.init_cash_total = None
        self.coin_str = coinMarketType.split('_')[0]
        self.ex_1_coin_reserve = None
        self.ex_2_coin_reserve = None
        self.ex_1_cash_reserve = None
        self.ex_2_cash_reserve = None
        self.ex_1_init_cash = None
        self.ex_2_init_cash = None
        self.ex_1_init_coin = None
        self.ex_2_init_coin = None
        self.ex_1_init_acct_info = None
        self.ex_2_init_acct_info = None
        self.ex_2_adj_bid, self.ex_2_adj_ask = None, None
        self.ex_1_bid_1, self.ex_1_ask_1 = None, None
        self.current_ex_1_acct_info = None
        self.current_ex_2_acct_info = None
        self.coin_str = coinMarketType.split('_')[0]

    def init_acct_info(self, ex_1_acct_info=None, ex_2_acct_info=None):
        if self.init_cash_total is None or self.init_coin_total is None:
            if not ex_1_acct_info:
                ex_1_acct_info = self.get_account_info(exchange=self.ex_1)
            if not ex_2_acct_info:
                ex_2_acct_info = self.get_account_info(exchange=self.ex_2)
            self.ex_1_init_cash = self.ex_cash_total(self.ex_1, acct_info=ex_1_acct_info)
            self.ex_2_init_cash = self.ex_cash_total(self.ex_2, acct_info=ex_2_acct_info)
            self.ex_1_init_coin = self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info)
            self.ex_2_init_coin = self.ex_coin_total(self.ex_2, acct_info=ex_2_acct_info)
            self.init_cash_total = self.ex_1_init_cash + self.ex_2_init_cash
            self.init_coin_total = self.ex_1_init_coin + self.ex_2_init_coin
            return False
        else:
            return True

    def ex_coin_total(self, ex, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        coin_total = acct_info.__getattribute__(self.coin_str + '_total')
        return coin_total

    def ex_cash_total(self, ex, acct_info=None):
        if not acct_info:
            acct_info = self.get_account_info(exchange=ex)
        cash_total = acct_info.__getattribute__('cash_total')
        return cash_total

    def set_up_reserve(self):
        self.ex_1_coin_reserve = self.ex_1_init_coin * cfg.EX_1_RESERVE
        self.ex_1_cash_reserve = self.ex_1_init_cash * cfg.EX_1_RESERVE
        self.ex_2_coin_reserve = self.ex_2_init_coin * cfg.EX_2_RESERVE
        self.ex_2_cash_reserve = self.ex_2_init_cash * cfg.EX_2_RESERVE

    def set_up_init_acct_info(self):
        if not self.ex_1_init_acct_info:
            self.ex_1_init_acct_info = self.get_account_info(exchange=self.ex_1)
        if not self.ex_2_init_acct_info:
            self.ex_2_init_acct_info = self.get_account_info(exchange=self.ex_2)
        if self.ex_1_init_acct_info and self.ex_2_init_acct_info:
            self.init_acct_info(ex_1_acct_info=self.ex_1_init_acct_info, ex_2_acct_info=self.ex_2_init_acct_info)
            self.set_up_reserve()
            return True
        else:
            return False

    def fetch_acct_info(self):
        self.current_ex_1_acct_info = self.get_account_info(self.ex_1)
        self.current_ex_2_acct_info = self.get_account_info(self.ex_2)
        if not all([self.current_ex_1_acct_info, self.current_ex_2_acct_info]):
            return False
        return self.current_ex_1_acct_info, self.current_ex_2_acct_info

    def pnl(self, coin_delta, cash_delta, current_price=None):
        current_price = current_price or self.get_buy_or_sell_n_price_or_vol(self.ex_2, 0, 0)
        if current_price is None:
            raise Exception('Fail to get acct info or market price')
        pnl = cash_delta + coin_delta * current_price
        return pnl

    def coin_type_and_currency(self, pair=None):
        if not pair:
            pair = self.coinMarketType
        coin_type, currency = pair.split('_')
        if currency == 'cny':
            currency = 'cash'
        return coin_type, currency

    def cal_pnl(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None, current_price=None):
        coin_delta = self.get_coin_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info, pair=pair)
        cash_delta = self.get_cash_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info, pair=pair)
        if coin_delta is not None and cash_delta is not None:
            return self.pnl(coin_delta, cash_delta, current_price=current_price)

    def get_coin_delta(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None):
        self.set_up_init_acct_info()
        ex_1_acct_info = ex_1_acct_info or self.get_account_info(self.ex_1)
        ex_2_acct_info = ex_2_acct_info or self.get_account_info(self.ex_2)
        if not all([ex_1_acct_info, ex_2_acct_info]):
            raise Exception('Fail to get acct info or market price')
        # coin_type, currency = self.coin_type_and_currency(pair=pair)
        coin_total = self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info) + self.ex_coin_total(self.ex_2,
                                                                                                  acct_info=ex_2_acct_info)
        coin_delta = coin_total - self.init_coin_total
        return coin_delta

    def get_cash_delta(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None):
        self.set_up_init_acct_info()
        ex_1_acct_info = ex_1_acct_info or self.get_account_info(self.ex_1)
        ex_2_acct_info = ex_2_acct_info or self.get_account_info(self.ex_2)
        if not all([ex_1_acct_info, ex_2_acct_info]):
            raise Exception('Fail to get acct info or market price')
        cash_total = self.ex_cash_total(self.ex_1, acct_info=ex_1_acct_info) + self.ex_cash_total(self.ex_2,
                                                                                                  acct_info=ex_2_acct_info)
        cash_delta = cash_total - self.init_cash_total
        return cash_delta

    def price_round_down(self, price):
        price_step = Decimal(str(cfg.K_skip))
        price = Decimal(str(price))
        adj_price = Decimal(str(int(price / price_step))) * price_step
        return numpy.float64(adj_price)

    def price_round_up(self, price):
        price_step = Decimal(str(cfg.K_skip))
        price = Decimal(str(price))
        adj_price = Decimal(str(math.ceil(price / price_step))) * price_step
        return numpy.float64(adj_price)

    def adj_bid_price(self, bid_price):
        adj_price = bid_price * (1 - cfg.fee_ex_2) * (1 - cfg.fee_ex_1) * (1 - cfg.slippage_bid)
        return self.price_round_down(adj_price)

    def adj_ask_price(self, ask_price):
        adj_price = ask_price * (1 + cfg.fee_ex_2) * (1 + cfg.fee_ex_1) * (1 + cfg.slippage_ask)
        return self.price_round_up(adj_price)

    def fetch_target_ex_depth(self, ex):
        discount_ratio = cfg.DEPTH_RATIO
        depth = self.get_depth(ex)
        if depth is None:
            return False
        bid = depth[0]
        ask = depth[1]
        adjBid = []
        adjAsk = []
        current_depth = 0
        while current_depth < len(bid):
            adj_price = self.adj_bid_price(float(bid[current_depth][0]))
            q_sum_bid = 0
            while self.adj_bid_price(float(bid[current_depth][0])) > adj_price - cfg.K_skip:
                q_sum_bid += float(bid[current_depth][1])
                current_depth += 1
                if current_depth >= len(bid):
                    break
            adjBid.append([adj_price, q_sum_bid * discount_ratio])

        current_depth = 0
        while current_depth < len(ask):
            adj_price = self.adj_ask_price(float(ask[current_depth][0]))
            q_sum_ask = 0
            while self.adj_ask_price(float(ask[current_depth][0])) < adj_price + cfg.K_skip:
                q_sum_ask += float(ask[current_depth][1])
                current_depth += 1
                if current_depth >= len(ask):
                    break
            adjAsk.append([adj_price, q_sum_ask * discount_ratio])

        self.ex_2_adj_bid = pd.DataFrame(adjBid, columns=['price', 'volume'])
        self.ex_2_adj_ask = pd.DataFrame(adjAsk, columns=['price', 'volume'])

        self.ex_2_adj_bid['price'] = self.ex_2_adj_bid['price'] - cfg.bid_spread
        self.ex_2_adj_ask['price'] = self.ex_2_adj_ask['price'] + cfg.ask_spread

        return self.ex_2_adj_bid, self.ex_2_adj_ask

    def init_process(self):
        self.ex_2_adj_bid, self.ex_2_adj_ask = None, None
        self.ex_1_bid_1, self.ex_1_ask_1 = None, None
        if not self.set_up_init_acct_info():
            return False
        if not self.fetch_acct_info():
            return False
        if not self.fetch_target_ex_depth(self.ex_2):
            return False
        return True

    def max_qty_available_buy(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None, current_price=None):
        ex_1_acct_info = ex_1_acct_info or self.get_account_info(self.ex_1)
        ex_2_acct_info = ex_2_acct_info or self.get_account_info(self.ex_2)
        current_price = current_price or self.get_buy_or_sell_n_price_or_vol(self.ex_2, 0, 0)
        if not all([ex_1_acct_info, ex_2_acct_info, current_price]):
            raise Exception('Fail to get acct info or market price')
        if not self.ex_2_coin_reserve:
            self.set_up_reserve()
        coin_type, currency = self.coin_type_and_currency(pair=pair)
        ex_2_coin_available = ex_2_acct_info.__getattribute__(coin_type) - self.ex_2_coin_reserve
        ex_1_cash_available = ex_1_acct_info.__getattribute__(currency) - self.ex_1_cash_reserve
        ex_1_max_buy = ex_1_cash_available / (current_price * (1 + cfg.slippage_bid))
        ex_2_max_sell = ex_2_coin_available
        max_to_buy = min(ex_1_max_buy, ex_2_max_sell)
        self.timeLog('最多可买[%.4f], 所用资金[%.4f]' % (max_to_buy, max_to_buy * (current_price * (1 + cfg.slippage_bid))))
        return max_to_buy

    def max_qty_available_sell(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None, current_price=None):
        ex_1_acct_info = ex_1_acct_info or self.get_account_info(self.ex_1)
        ex_2_acct_info = ex_2_acct_info or self.get_account_info(self.ex_2)
        current_price = current_price or self.get_buy_or_sell_n_price_or_vol(self.ex_2, 1, 0)
        if not all([ex_1_acct_info, ex_2_acct_info, current_price]):
            raise Exception('Fail to get acct info or market price')
        if not self.ex_2_cash_reserve:
            self.set_up_reserve()
        coin_type, currency = self.coin_type_and_currency(pair=pair)
        ex_2_cash_available = ex_2_acct_info.__getattribute__(currency) - self.ex_2_cash_reserve
        ex_1_coin_available = ex_1_acct_info.__getattribute__(coin_type) - self.ex_1_coin_reserve
        ex_1_max_sell = ex_1_coin_available
        ex_2_max_buy = ex_2_cash_available / (current_price * (1 + cfg.slippage_ask))
        max_to_sell = min(ex_1_max_sell, ex_2_max_buy)
        return max_to_sell

    def hedge_delta(self):
        while True:
            time.sleep(cfg.hedge_freq)
            self.timeLog('<Hedging thread> heart beat')
            try:
                retry_time = 3
                cancel_success = False
                while retry_time > 0:
                    try:
                        retry_time -= 1
                        self.cancel_pending_orders(self.ex_2)
                        cancel_success = True
                    except Exception:
                        continue
                if not cancel_success:
                    raise Exception('<Hedging>[%s]撤单失败' % self.ex_2)
                ex_1_acct_info = self.get_account_info(self.ex_1)
                ex_2_acct_info = self.get_account_info(self.ex_2)
                if not all([ex_1_acct_info, ex_2_acct_info]):
                    raise Exception('<Hedging>Acct init fail')
                cash_delta, coin_delta = self.borrowed_delta(ex_1_acct_info, ex_2_acct_info)
                buy_1_price = self.get_buy_or_sell_n_price_or_vol(self.ex_2, 0, 0)
                sell_1_price = self.get_buy_or_sell_n_price_or_vol(self.ex_2, 1, 0)
                if not all([buy_1_price, sell_1_price]):
                    raise Exception('<Hedging>Get market price fail')
                if coin_delta > cfg.HEDGE_MIN_DELTA:
                    self.timeLog('<Hedging Sell> delta = %.6f' % coin_delta)
                    self.timeLog('<Hedging>[%s]下单sell， price=%.6f, qty=%.6f' % (
                    self.ex_2, buy_1_price * (1 - cfg.slippage_ask), coin_delta))
                    self.spot_order(self.ex_2, self.coinMarketType, helper.SPOT_TRADE_TYPE_SELL,
                                    helper.ORDER_TYPE_LIMIT_ORDER, price=buy_1_price * (1 - cfg.slippage_ask),
                                    quantity=coin_delta)
                    # self.polo_sell_limit(buy_1_price * (1-cfg.slippage_ask), coin_delta)
                elif -coin_delta > cfg.HEDGE_MIN_DELTA:
                    self.timeLog('<Hedging Buy> delta = %.6f' % coin_delta)
                    self.timeLog(
                        '<Hedging>[%s]下单buy， price=%.6f, qty=%.6f' % (
                        self.ex_2, sell_1_price * (1 + cfg.slippage_bid), -coin_delta))
                    self.spot_order(self.ex_2, self.coinMarketType, helper.SPOT_TRADE_TYPE_BUY,
                                    helper.ORDER_TYPE_LIMIT_ORDER, price=buy_1_price * (1 - cfg.slippage_ask),
                                    quantity=-coin_delta)
                    # self.polo_buy_limit(sell_1_price * (1+cfg.slippage_bid), -coin_delta)
                else:
                    self.timeLog('<Hedging>current_delta = %.6f' % coin_delta)
            except Exception as e:
                self.timeLog('<Hedging exception>: %s' % e)
                continue

    def update_ex_1_active_orders(self, pair=None):
        if not pair:
            pair = self.coinMarketType
        symbol = pair.replace('_', '')
        orders = self.get_active_orders(self.ex_1)
        buy_orders = dict()
        sell_orders = dict()
        no_buy_orders = 0
        no_sell_orders = 0
        buy_qty_total = 0
        sell_qty_total = 0
        buy_price = set([row.price for index, row in self.ex_2_adj_bid.iterrows()])
        sell_price = set([row.price for index, row in self.ex_2_adj_ask.iterrows()])
        cancel_order_id_list = list()
        for order in orders:
            order_price = numpy.float64(order['order_price'])
            order_id = order['order_id']
            order_remaining_qty = float(order['order_amount']) - float(order['proccessed_amount'])
            if order['trade_type'] == 'buy':
                no_buy_orders += 1
                buy_qty_total += order_remaining_qty
                if order_price in buy_price:
                    if order_price in buy_orders:
                        buy_orders[order_price].append({'order-id': order_id, 'remaining-qty': order_remaining_qty})
                    else:
                        buy_orders.update({order_price: [{'order-id': order_id, 'remaining-qty': order_remaining_qty}]})
                else:
                    cancel_order_id_list.append(str(order_id))
            elif order['trade_type'] == 'sell':
                no_sell_orders += 1
                sell_qty_total += order_remaining_qty
                if order_price in sell_price:
                    if order_price in sell_orders:
                        sell_orders[order_price].append({'order-id': order_id, 'remaining-qty': order_remaining_qty})
                    else:
                        sell_orders.update(
                            {order_price: [{'order-id': order_id, 'remaining-qty': order_remaining_qty}]})
                else:
                    cancel_order_id_list.append(str(order_id))
        self.timeLog("cancel_order_id_list:{0}".format(cancel_order_id_list))
        self.cancel_pending_orders(exchange=self.ex_1, order_id_list=cancel_order_id_list)
        self.timeLog('买入订单总数[%s], 数量[%.4f]; 卖出订单总数[%s], 数量[%.4f]' % (
        no_buy_orders, buy_qty_total, no_sell_orders, sell_qty_total))
        return buy_orders, sell_orders

    def place_buy_orders(self, ex_2_adj_bid, current_buy_orders):
        """
        :type ex_2_adj_bid: pd.DataFrame
        :param current_buy_orders: dict
        :return:
        """
        max_buy_qty = self.max_qty_available_buy()
        remaining_qty = max_buy_qty
        for index, row in ex_2_adj_bid.iterrows():
            time.sleep(1)
            price = row.price
            volume = min(row.volume, remaining_qty)
            # 当前价格在活跃订单中
            if price in current_buy_orders:
                order_list = current_buy_orders[price]
                total_qty = 0
                order_id_list = list()
                for order in order_list:
                    total_qty += order['remaining-qty']
                    order_id_list.append(str(order['order-id']))
                if total_qty > volume:
                    self.cancel_pending_orders(exchange=self.ex_1, order_id_list=order_id_list)
                    qty_to_buy = min(volume, remaining_qty)
                    qty_to_buy = min(qty_to_buy, cfg.max_qty_per_order)
                    if qty_to_buy > cfg.min_qty_per_order:
                        self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_BUY,
                                        helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_buy)
                        remaining_qty -= qty_to_buy
                elif total_qty <= volume:
                    qty_to_buy = min(volume - total_qty, remaining_qty)
                    qty_to_buy = min(qty_to_buy, cfg.max_qty_per_order)
                    if qty_to_buy > cfg.min_qty_per_order:
                        self.timeLog('价格[%.4f]追加买单数量[%.6f]' % (price, qty_to_buy))
                        self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_BUY,
                                        helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_buy)
                        remaining_qty -= qty_to_buy
            else:
                qty_to_buy = min(volume, remaining_qty)
                qty_to_buy = min(qty_to_buy, cfg.max_qty_per_order)
                if qty_to_buy > cfg.min_qty_per_order:
                    self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_BUY,
                                    helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_buy)
                    remaining_qty -= qty_to_buy
            if remaining_qty < cfg.min_qty_per_order:
                return

    def place_sell_orders(self, ex_2_adj_ask, current_sell_orders):
        """
        :type ex_2_adj_ask: pd.DataFrame
        :param current_sell_orders: dict
        :return:
        """
        max_sell_qty = self.max_qty_available_sell()
        remaining_qty = max_sell_qty
        for index, row in ex_2_adj_ask.iterrows():
            time.sleep(1)
            price = row.price
            volume = min(row.volume, remaining_qty)
            # 当前价格在活跃订单中
            if price in current_sell_orders:
                order_list = current_sell_orders[price]
                total_qty = 0
                order_id_list = list()
                for order in order_list:
                    total_qty += order['remaining-qty']
                    order_id_list.append(str(order['order-id']))
                if total_qty > volume:
                    self.cancel_pending_orders(exchange=self.ex_1, order_id_list=order_id_list)
                    qty_to_sell = min(volume, remaining_qty)
                    qty_to_sell = min(qty_to_sell, cfg.max_qty_per_order)
                    if qty_to_sell > cfg.min_qty_per_order:
                        self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_SELL,
                                        helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_sell)
                        remaining_qty -= qty_to_sell
                elif total_qty <= volume:
                    qty_to_sell = min(volume - total_qty, remaining_qty)
                    qty_to_sell = min(qty_to_sell, cfg.max_qty_per_order)
                    if qty_to_sell > cfg.min_qty_per_order:
                        self.timeLog('价格[%.4f]追加卖单数量[%.6f]' % (price, qty_to_sell))
                        self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_SELL,
                                        helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_sell)
                        remaining_qty -= qty_to_sell
            else:
                qty_to_sell = min(volume, remaining_qty)
                qty_to_sell = min(qty_to_sell, cfg.max_qty_per_order)
                if qty_to_sell > cfg.min_qty_per_order:
                    self.spot_order(self.ex_1, self.coinMarketType, helper.SPOT_TRADE_TYPE_SELL,
                                    helper.ORDER_TYPE_LIMIT_ORDER, price=price, quantity=qty_to_sell)
                    remaining_qty -= qty_to_sell
            if remaining_qty < cfg.min_qty_per_order:
                return

    def place_orders(self):
        buy_active_orders, sell_active_orders = self.update_ex_1_active_orders()
        print('当前买单', buy_active_orders)
        print('当前卖单', sell_active_orders)
        self.timeLog("place buy orders")
        self.place_buy_orders(self.ex_2_adj_bid, buy_active_orders)
        self.timeLog("place sell orders")
        self.place_sell_orders(self.ex_2_adj_ask, sell_active_orders)

    def borrowed_delta(self, ex_1_acct_info=None, ex_2_acct_info=None, pair=None):
        ex_1_acct_info = ex_1_acct_info or self.get_account_info(self.ex_1)
        ex_2_acct_info = ex_2_acct_info or self.get_account_info(self.ex_2)
        if not all([ex_1_acct_info, ex_2_acct_info]):
            raise Exception('Fail to get acct info or market price')
        # pair = pair or self.coinMarketType
        # coin_type, currency = self.coin_type_and_currency(pair=pair)
        ex_1_cash_total = self.ex_cash_total(self.ex_1, acct_info=ex_1_acct_info)
        ex_2_cash_total = self.ex_cash_total(self.ex_2, acct_info=ex_2_acct_info)
        ex_1_coin_total = self.ex_coin_total(self.ex_1, acct_info=ex_1_acct_info)
        ex_2_coin_total = self.ex_coin_total(self.ex_2, acct_info=ex_2_acct_info)
        cash_delta = (ex_1_cash_total + ex_2_cash_total) - cfg.currency_borrow
        coin_delta = (ex_1_coin_total + ex_2_coin_total) - cfg.coin_borrow
        return cash_delta, coin_delta

    def total_pnl(self, ex_1_acct_info=None, ex_2_acct_info=None, current_price=None, pair=None):
        cash_delta, coin_delta = self.borrowed_delta(ex_1_acct_info=ex_1_acct_info, ex_2_acct_info=ex_2_acct_info,
                                                     pair=pair)
        return self.pnl(coin_delta, cash_delta)

    def monitor(self):
        pnl = self.cal_pnl(self.current_ex_1_acct_info, self.current_ex_2_acct_info)
        total_pnl = self.total_pnl(self.current_ex_1_acct_info, self.current_ex_2_acct_info)
        self.timeLog('Current P/L = %.6f' % pnl)
        self.timeLog('Total P/L = %.6f' % total_pnl)
        if pnl < cfg.warn_pnl:
            self.timeLog('<Warning>!!! P/L = %.6f, greater than max loss(%.6f).' % (pnl, cfg.warn_pnl),
                         level=logging.WARNING)
        elif pnl < cfg.stop_pnl:
            self.cancel_pending_orders(self.ex_1)
            self.timeLog('<Stop>!!! P/L = %.6f, greater than max loss(%.6f).' % (pnl, cfg.stop_pnl),
                         level=logging.WARNING)
            return False
        if self.reserve_monitor() is False:
            return False
        return True

    def reserve_monitor(self):
        ex_1_cash_available, ex_1_coin_available = self.acct_available(self.current_ex_1_acct_info)
        ex_2_cash_available, ex_2_coin_available = self.acct_available(self.current_ex_2_acct_info)
        if self.ex_1_coin_reserve is None:
            self.set_up_reserve()
        if ex_1_cash_available < self.ex_1_cash_reserve:
            self.timeLog('<Warning>[%s]当前可用currency为[%.4f], 小于reserve[%.4f]' % (
            self.ex_1, ex_1_cash_available, self.ex_1_cash_reserve))
            return False
        elif ex_1_coin_available < self.ex_1_coin_reserve:
            self.timeLog('<Warning>[%s]当前可用coin为[%.4f], 小于reserve[%.4f]' % (
            self.ex_1, ex_2_coin_available, self.ex_1_coin_reserve))
            return False
        elif ex_2_cash_available < self.ex_2_cash_reserve:
            self.timeLog('<Warning>[%s]当前可用currency为[%.4f], 小于reserve[%.4f]' % (
            self.ex_2, ex_2_cash_available, self.ex_2_cash_reserve))
            return False
        elif ex_2_coin_available < self.ex_2_coin_reserve:
            self.timeLog('<Warning>[%s]当前可用coin为[%.4f], 小于reserve[%.4f]' % (
            self.ex_2, ex_2_coin_available, self.ex_2_coin_reserve))
            return False
        return True

    def acct_available(self, acct_info, pair=None):
        pair = pair or self.coinMarketType
        coin_type, currency = self.coin_type_and_currency(pair=pair)
        if currency == 'cny':
            currency = 'cash'
        cash_available = acct_info.__getattribute__(currency)
        coin_available = acct_info.__getattribute__(coin_type)
        return cash_available, coin_available

    def cancel_all_pending_orders(self):
        try:
            self.cancel_pending_orders(self.ex_1)
            self.cancel_pending_orders(self.ex_2)
            return True
        except Exception:
            return False

    def go(self):
        self.cancel_all_pending_orders()
        t = Thread(target=self.hedge_delta, args=())
        t.setDaemon(True)
        t.start()
        while True:
            try:
                if not self.init_process():
                    self.timeLog('获取账户/行情信息失败，重新尝试')
                    time.sleep(2)
                    if not self.init_process():
                        self.timeLog('<Warning>再次获取账户/行情信息失败，撤销所有订单')
                        self.cancel_pending_orders(self.ex_1)
                    continue
                if not self.monitor():
                    self.cancel_pending_orders(exchange=self.ex_1)
                    continue
                self.place_orders()
                time.sleep(10)
            except Exception as e:
                self.timeLog(e)
                continue
