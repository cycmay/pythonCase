# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee

ex_1_coin = 50
ex_2_coin = 35.702452

ex_1_cash = 1500000
ex_2_cash = 1000888

# coin_borrow = 85.702452
# currency_borrow = 2500888

coin_borrow = ex_1_coin + ex_2_coin
currency_borrow = ex_1_cash + ex_2_cash

SLIPPAGE = 0.001

EX_1_RESERVE = 0.9
EX_2_RESERVE = 0.9

DEPTH_RATIO = 0.01  # 下单数量占此深度的比例

K_skip = 50  # 每隔此数值的价格，合并一次深度
bid_spread = 1000  # 买盘向下调整数值
ask_spread = 1000  # 卖盘向上调整数值

fee_ex_1 = 0.000
fee_ex_2 = 0.002

slippage_bid = 0.002
slippage_ask = 0.002

min_qty_per_order = 0.05
max_qty_per_order = 1

hedge_freq = 10

warn_pnl = -100
stop_pnl = -500

HEDGE_MIN_DELTA = 0.001  # 小于此值时，不会对冲
