# !/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import time
from multiprocessing import Process, Manager

from marketData import accountInfo
from marketData import depthData
from strat import Strat
import serverConfig
from utils import helper

# COIN_TYPE = "btc_cny"  # 在此处填写需要交易的币种: "btc_cny", "ltc_cny", "eth_cny"
COIN_TYPE = "act_cny"  # 在此处填写需要交易的币种: "btc_cny", "ltc_cny", "eth_cny"
# EXCHANGE_LIST = ["huobi"]  # 需要查询账户和行情的交易所名字："huobi", "okcoin", "bitex", "bitvc"
EXCHANGE_LIST = ["ourdax", "jubi"]  # 需要查询账户和行情的交易所名字："huobi", "okcoin", "bitex", "bitvc"
# STRAT_NAME = 'BTC自成交'
STRAT_NAME = 'ACT_CNY'

def depth_info_proc(exchange_list, coin_type, depth_data, strat):
    depth_proc_list = list()
    for exchange in exchange_list:
        if exchange == helper.HUOBI:
            depth_proc = Process(target=depthData.huobi_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.OKCOIN:
            depth_proc = Process(target=depthData.okcoin_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.BITEX:
            depth_proc = Process(target=depthData.bitex_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.BITVC:
            depth_proc = Process(target=depthData.bitvc_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.PRO:
            depth_proc = Process(target=depthData.pro_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.POLO:
            depth_proc = Process(target=depthData.polo_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.CHBTC:
            depth_proc = Process(target=depthData.chbtc_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.JUBI:
            depth_proc = Process(target=depthData.jubi_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        elif exchange == helper.OURDAX:
            depth_proc = Process(target=depthData.ourdax_depth,
                                 args=(coin_type, helper.DATA_DEPTH, depth_data, strat.timeLog))
        depth_proc.name = exchange + '_depth_data_proc'
        depth_proc_list.append(depth_proc)
    return depth_proc_list


def acct_info_proc(exchange_list, coin_type, account_info, strat, huobi_key_index='CNY_1', bitex_key_index='CNY_1'):
    ex_dict = dict()
    for ex in exchange_list:
        ex_dict.update({ex: True})
    account_info_proc = Process(target=accountInfo.getAccountInfo, args=(account_info, coin_type, strat.timeLog), kwargs=ex_dict)
    account_info_proc.name = 'account_info_proc'
    return account_info_proc


def start_all_proc(proc_list):
    for proc in proc_list:
        proc.daemon = True
        proc.start()


def monitor_all_proc(proc_list, strat):
    latest_email_time = time.time()
    alert_email_sent = False
    last_alert_email_time = 0
    while True:
        time.sleep(serverConfig.PROCESS_MONITOR_FREQ)
        proc_name_list = list()
        proc_status_list = list()
        for proc in proc_list:
            proc_name_list.append(proc.name)
            proc_status_list.append(proc.is_alive())

        # 所有进程都在工作
        if all(proc_status_list):
            continue
            # 距离上次发送进程监控正常报告时间超过了用户自定义的时间，则发送新的邮件
            # if (time.time() - latest_email_time) >= serverConfig.MONITOR_NORMAL_EMAIL_FREQ:
            #     sent_normal_email = emailSender.process_normal_email(strat.instanceId, strat.timeLog, strat.strat_name)
            #     # 邮件发送成功，更新latest_email_time
            #     if sent_normal_email:
            #         latest_email_time = time.time()
        # 有的进程不工作
        else:
            for i in range(len(proc_name_list)):
                strat.timeLog('%s 状态：%s' % (proc_name_list[i], proc_status_list[i]))
            # if not alert_email_sent:
            #     emailSender.process_alert_email(strat.instanceId, proc_name_list, proc_status_list, strat.timeLog,
            #                                     strat.strat_name)
            #     last_alert_email_time = time.time()
            #     alert_email_sent = True
            # elif time.time() - last_alert_email_time > serverConfig.MONITOR_ALERT_EMAIL_FREQ:
            #     emailSender.process_alert_email(strat.instanceId, proc_name_list, proc_status_list, strat.timeLog,
            #                                     strat.strat_name)
            #     last_alert_email_time = time.time()
            #     alert_email_sent = True


def main(key_index):
    # 设置进程间共享Value -- 心跳时间
    server = Manager()
    heartbeat_time = server.Value('d', time.time())
    # 设置进程间共享Dict -- 深度数据
    depth_data = server.dict()
    account_info = server.dict()
    # 设置策略的币种
    coin_type = COIN_TYPE  # 比特币

    # 记录所有开启的进程
    proc_list = list()

    huobi_key_index, bitex_key_index = 'CNY_1', 'CNY_1'
    if 'bitex' in EXCHANGE_LIST:
        exchange = 'bitex'
        bitex_key_index = key_index
    elif 'huobi' in EXCHANGE_LIST:
        exchange = 'huobi'
        huobi_key_index = key_index
    else:
        exchange = None
    strat = Strat(heartbeat_time, coin_type, EXCHANGE_LIST[0], EXCHANGE_LIST[1],
                    depth_data=depth_data, account_info=account_info)


    # 获取行情深度进程
    depth_proc = depth_info_proc(EXCHANGE_LIST, coin_type, depth_data, strat)
    proc_list.extend(depth_proc)

    # 获取账户信息进程
    account_info_proc = acct_info_proc(EXCHANGE_LIST, coin_type, account_info, strat, bitex_key_index=bitex_key_index,
                                       huobi_key_index=huobi_key_index)
    proc_list.append(account_info_proc)


    # 策略进程
    strat_proc = Process(target=helper.start_strat, args=(strat,))
    strat_proc.name = 'strat_proc'
    proc_list.append(strat_proc)
    #
    start_all_proc(proc_list)
    monitor_all_proc(proc_list, strat)

    # print(strat.get_chbtc_account_info().__dict__)
    # print("strategy",strat.get_depth("chbtc"))


if __name__ == "__main__":
    if len(sys.argv) > 1:
        key_index = sys.argv[1]
    else:
        key_index = "CNY_1"
    main(key_index)

