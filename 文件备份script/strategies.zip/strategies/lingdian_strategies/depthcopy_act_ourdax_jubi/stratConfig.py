# !/usr/bin/env python
# -*- coding: utf-8 -*-

# @Author : Lloyd Lee

ex_1_coin = 5516952.05048
ex_2_coin = 626922.3094775

ex_1_cash = 2462943.375078
ex_2_cash = 134740.42189616

# coin_borrow = 85.702452
# currency_borrow = 2500888

coin_borrow = ex_1_coin + ex_2_coin
currency_borrow = ex_1_cash + ex_2_cash

SLIPPAGE = 0.001

EX_1_RESERVE = 0.2
EX_2_RESERVE = 0.2

DEPTH_RATIO = 0.1  # 下单数量占此深度的比例

K_skip = 0.003  # 每隔此数值的价格，合并一次深度
bid_spread = 0.01  # 买盘向下调整数值
ask_spread = 0.01  # 卖盘向上调整数值

fee_ex_1 = 0.000
fee_ex_2 = 0.001

slippage_bid = 0.002
slippage_ask = 0.002

min_qty_per_order = 200
max_qty_per_order = 5000

hedge_freq = 10

warn_pnl = -100
stop_pnl = -500

HEDGE_MIN_DELTA = 20  # 小于此值时，不会对冲
