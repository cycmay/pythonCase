# !/usr/bin/env python
# -*- coding: utf-8 -*-
# huobi config
HUOBI = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.huobi.com/apiv3",
        },
}

CHBTC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",  # 途
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://api.chbtc.com/",
        },
}

JUBI = {
    "CNY_1":
        {
            "ACCESS_KEY": '52tsi-9mygm-k3gyw-1dp1h-daz63-dctat-sevj7',
            "SECRET_KEY": 'y.,tn-A)t^^-k&n((-]sjZF-ra@by-R&.HE-2(q/p'
        }
}

OKCOIN = {
    "CNY_1":
        {
            "ACCESS_KEY": "",  # ourdax借深度
            "SECRET_KEY": "",

            "SERVICE_API": "https://www.okcoin.cn",  # okcoin国内站
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITVC = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

POLO = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
            "SERVICE_API": "https://www.okcoin.cn", # okcoin国内站
            "FUTURE_SERVICE_API": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

BITEX = {
    "CNY_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        },

    "USD_1":
        {
            "ACCESS_KEY": "",
            "SECRET_KEY": "",
        }
}

OURDAX = {
    "CNY_1":
        {
            # "ACCESS_KEY": "100000116050600000",  # test
            # "SECRET_KEY": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJHT1AifQ.67vZPENUXFLdZXLr0tZZuz5RA6DzlhOeG6wO2l8uSb1nVkPQ3XMMRKcQ016j7rr-zU8bDERmk4P_NO5pK_cc-g",
            "ACCESS_KEY": "100000116050600001",  # depth copy from jubi act
            "SECRET_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HuQ",
        }
}
